# -*- coding: utf-8 -*-
"""
Created on Mon Jul 17 13:13:52 2017

@author: Arash
"""
#encoding is like 1.234 = '1234' , 0.433 = '0433'

#imports
import numpy as np
import random
import matplotlib.pyplot as plt
import math
import statsmodels.api as sm

#functions 
def Init_pop(pop) :
    #breeding the first population of 100*
    i = 0
    while(i < population_Size) : #chromosomes in the first population*
        #randomly generate a 4-digit number :
            #we have 3 variABLE to encode
       chromosome = ''
       n = 1
       while(n < 4) : 
            #the first gene's alleles are different from the rest
            bgene = str(random.randint(0,1))
            chromosome += bgene
            j = 1
            while( j < 4 ) :
                gene = str(random.randint(0,9))
                chromosome += gene
                j += 1
            n += 1
       
       #check and see if the fitness is above zero, add the chromosome to pop
       x = int(chromosome[0:4])/1000 #/1000 bc of getting a float with 3 decimal digits
       y = int(chromosome[4:8])/1000
       z = int(chromosome[8:12])/1000
       fitness = eval(func)
       if(fitness >= 0) :
           i += 1
           pop[-1].append(chromosome)


def Fitness(pop,points,ffitness) :
    i = 0
    while(i < population_Size) : #for all the populations chromosomes*
        x = int(pop[-1][i][0:4])/1000
        y = int(pop[-1][i][4:8])/1000
        z = int(pop[-1][i][8:12])/1000
        points[-1].append(x*y*z)
        if(x*y*z < 0.1) : 
            fitness = eval(nearZeroFunc)
        else :
            fitness = eval(func)
        ffitness[-1].append(fitness)
        i += 1

        
def Selection(parent,fitPopSorted,fitsumSelec) : 
   randNum = np.random.uniform(0,1)
   t = 0 #for counting
   a = 0 #summation of the beforehand fitnesses, I wanna use tower sampling
   while(t < (population_Size/5)+1) : #using a loop to find where of the tower our random number lands
       if( randNum < a + fitPopSorted[t][0]/fitsumSelec ) :
           parent.append(fitPopSorted[t][1])#from tth fitness population tuple, population
           break
       else : 
           a += fitPopSorted[t][0]/fitsumSelec
           t += 1

           
def Crossover(parent) :
    randNum = np.random.uniform(0,1) #crossover probability of happening check
    crsRate = 0.7 #crossover rate
    if(randNum > crsRate) : 
        randNum = []
        randNum.append(random.randint(0,11))
        randNum.append(random.randint(0,11))
        randNum = sorted(randNum)
        child1 = parent[1][:randNum[0]] + parent[0][randNum[0]:randNum[1]] + parent[1][randNum[1]:]
        child2 = parent[0][:randNum[0]] + parent[1][randNum[0]:randNum[1]] + parent[0][randNum[1]:]
    else : 
        child1 = parent[0]
        child2 = parent[1]
    return(child1,child2)
     
           
 
def Mutation(child,children,mutRate) :
    o = 0
    while(o < 12) : 
        randNum = np.random.uniform(0,1)
        if(randNum <= mutRate) :
            if(o == 0 or 4 or 8) : 
                randNum = random.randint(0,1)
                child.replace(child[o],str(randNum))
            else : 
                randNum = np.randint(0,9)
                child.replace(child[o],str[randNum])
        o += 1                 
    children.append(child)


def Decoder(pop,result_points) : 
    j = 0
    result_points.append([])
    while( j < population_Size ) :
        x = int(pop[-1][j][0:4])/1000
        y = int(pop[-1][j][4:8])/1000
        z = int(pop[-1][j][8:12])/1000
        result_points[-1].append((x,y,z))
        j += 1

        

def run_func(plotSwitch,ffinalPoints, ffinalPoints_fitness,result_points) : 
#defining variables and constants
    ###the population variable###
    pop = []
    ffitness = []
    points = []

    ffitavg = [] #for plotting the variation in fitness

    pop.append([])
    Init_pop(pop) #making the first population
    
    #mkaing a hundread generations and then averaging to get 
    #the final result with randomness taken out to some extent
    j = 0
    while(j < generationNumber) : #generations
       
        #Fitness evaluation of the population
        ffitness.append([])
        points.append([])
        Fitness(pop,points,ffitness)
        #mkaing fitness and population tuples in a list for sorting
        fitPop = []
        i = 0
        while (i < population_Size) :
            fitPop.append( (ffitness[-1][i],pop[-1][i]) )
            i += 1
        
        #first - selection rule :
            #using random numbers
        # total fitness summation
        i = 0
        fitsum = 0
        while(i < population_Size) : 
            fitsum += ffitness[-1][i]
            i += 1    
        
        # fitness summation for selection (popsize must be even)
        fitPopSorted = sorted(fitPop, key = lambda tup : tup[0] ,reverse = True)        
        i = 0
        fitsumSelec = 0
        while(i < (population_Size/5)+1) : #only 20 percent 
            fitsumSelec += fitPopSorted[i][0]
            i += 1 
        
        
        k = 1
        children = []
        while(k < (population_Size/2) + 1) : #every loop = two children >>>>>>>>>>> one new population
        
            #fitness dependant selection
            parent = []
            w = 1
            while(w < 3) : #two parents
                Selection(parent,fitPopSorted,fitsumSelec) #of one parent
                w += 1
            
            #crossover
            child1 , child2 = Crossover(parent)
       
            #mutation
            Mutation(child1,children,mutRate)
            Mutation(child2,children,mutRate)
       
            k += 1
            pop.append(children)
            
        #average fitness calculation
        fitavg = fitsum / population_Size
        ffitavg.append(fitavg) 
        
        
            
        j += 1
        
        
        
           ###fitness of the last population:
    if(plotSwitch != 0) :
        plt.figure()
        plt.plot(np.linspace(0,generationNumber,generationNumber,dtype = int),ffitavg)
               
    ffitness.append([])
    points.append([])
    Fitness(pop,points,ffitness)
    
    Decoder(pop,result_points) #decodes the final results
    

    ffinalPoints_fitness.append(max(ffitness[-1])) #for plotting the results
    maxIndex = ffitness[-1].index(max(ffitness[-1]))
    ffinalPoints.append(points[-1][maxIndex])
    
def deviance() :
    
    sqrSum = 0
    i = 0
    while(i < runLeft+runRight) :
        sqr = result[i] ** 2
        sqrSum += sqr
        i += 1
    
    sqravg = sqrSum / (runLeft+runRight)
    avgsqr = finalpoint ** 2 #finalpoint is the mean result
    
    d = np.sqrt((sqravg - avgsqr)/(runLeft+runLeft-1))
    return(d)

def fitLine() :
    #for fitting we have to have two lists
    xx = []
    i = 0
    while(i < length-1) :
        xx.append(genResTups[i+1][0])
        i += 1
    yy = []
    i = 0
    while(i < length-1) :
        yy.append(genResTups[i+1][1])
        i += 1
    
    fitAr = np.polyfit(xx,yy,1) #1 is the degree of the polynomial >> 1 : linear
    tangent = fitAr[0]
    c = fitAr[1]
    f = '(tangent * x) + c'
    
    num = 10 #number of points for drawing the fit line
    xx1 = np.linspace(0,max(xx),num) #1/generationNumber is the largest point on the x axis
    ff = []
    i = 0
    while(i < num) :
        x = xx1[i]
        ff.append(eval(f))
        i += 1
    plt.plot(xx1,ff,'b')
    print(c, 'is the linear regression approximation result!')
    
def finResult(cc, iters) :
    summ = 0
    i = 0
    while(i < iters) :
        summ += cc[i]
        i += 1

    print('average result is :', summ/iters)
    print('with standard deviation : ',finDev(iters,cc,summ))
        
def fLine(genResTups,gSize) :
    plt.figure()

    deviList = [] #deviations list
    generations = []
    results = []
    rr = [] #gsize random indices

    i = 0
    while(i < gSize) :
        rr.append(np.random.randint(0,len(genResTups)-1))
        i += 1

    i = 0
    while(i < gSize) :
        j = rr[i]
        deviList.append(genResTups[0][j])
        i += 1
        
    i = 0
    while(i < gSize) :
        j = rr[i]
        if(j == 0) :
            j = 1
        generations.append(genResTups[j][0])
        i += 1
    
    i = 0
    while(i < gSize) :
        j = rr[i]  
        if(j == 0) :
            j = 1      
        results.append(genResTups[j][1])
        i += 1
    
    plt.plot(generations,results,'o') #add_constant turns x into an array
    
    generations = sm.add_constant(generations)
    wls = sm.WLS(results, generations, weights = deviList)
    fit = wls.fit()
    c, m = fit.params
    le = 'm*x + c'

    xx = np.linspace(0,0.02,100)
    ll = []
    i = 0
    while(i < 100) :
        x = xx[i]
        value = eval(le)
        ll.append(value)
        i += 1
    
    plt.plot(xx, ll) #fit line equation plot
    
    return(c)

def finDev(iters,cc,summ) :
    
    sqrSum = 0
    i = 0
    while(i < iters) :
        sqr = cc[i] ** 2
        sqrSum += sqr
        i += 1
    
    sqravg = sqrSum / iters
    avgsqr = (summ/iters) ** 2 #finalpoint is the mean result
    
    d = np.sqrt((sqravg - avgsqr)/(iters-1))
    return(d)
    
genResTups = [[]]
generationNumber = 50 #number of generation before the final result
maxGen = 400
while(generationNumber < maxGen+1) : 
    print('generationNumber',generationNumber)
    
    #body
    func = '(np.sin(x*y*z)/(x*y*z))**2'
    nearZeroFunc = '(1 - (((x*y*z)**2)/math.factorial(3)) + (((x*y*z)**4)/math.factorial(5)) - (((x*y*z)**6)/math.factorial(7)) + (((x*y*z)**8)/math.factorial(9)))**2'           
    ffinalPoints = [] #for plotting
    ffinalPoints_fitness = [] #single numbers
    result_points = [] #tiples
    population_Size = 100 
    mutRate = 0.1

    #This set of runs is for right side
    runRight = 10 #taking run runs
    r = 0
    while(r < runRight) :
        plotSwitch = 0 #generation plots, 0 means no
        run_func(plotSwitch,ffinalPoints, ffinalPoints_fitness,result_points)
        #ending the run while loop
        r += 1
    result = ffinalPoints
    #graphs and outputs
    plt.figure(); plt.xlabel('points'); plt.ylabel('fitness(f value)'); plt.title(generationNumber)
    plt.plot(ffinalPoints,ffinalPoints_fitness,'.')
    favgRight = sum(ffinalPoints_fitness)/runRight
    print('the average final fitness of the right side points: ',favgRight)
    xx = np.linspace(0.00001,0.01,100)
    ff = []
    i = 0
    while(i < 100) :
        x = xx[i]
        ff.append(eval('(1 - (((x)**2)/math.factorial(3)) + (((x)**4)/math.factorial(5)) - (((x)**6)/math.factorial(7)) + (((x)**8)/math.factorial(9)))**2'))
        i += 1
    plt.plot(xx,ff,'r')    
    



    #This set of runs is for left side
    ffinalPoints = [] #for plotting
    ffinalPoints_fitness = [] #single numbers
    result_points = [] #tiples
    runLeft = 10 #taking 'run' runs for left side
    r = 0
    while(r < runLeft) :
        plotSwitch = 0 #generation plots, 0 means no
        run_func(plotSwitch,ffinalPoints, ffinalPoints_fitness,result_points)
        #ending the run while loop
        r += 1
    result += ffinalPoints
    #graphs and outputs

    r = 0 
    while(r < runLeft) : #finding corresponding negative points
        ffinalPoints[r] = - ffinalPoints[r]
        r += 1
    
    plt.plot(ffinalPoints,ffinalPoints_fitness,'.')
    favgLeft = sum(ffinalPoints_fitness)/runLeft
    print('the average final fitness of the left side points: ',favgLeft)
    xx = np.linspace(-0.01,-0.00001,100)
    ff = []
    i = 0
    while(i < 100) :
        x = xx[i]
        ff.append(eval('(1 - (((x)**2)/math.factorial(3)) + (((x)**4)/math.factorial(5)) - (((x)**6)/math.factorial(7)) + (((x)**8)/math.factorial(9)))**2'))
        i += 1
    plt.plot(xx,ff,'r')


    #final result
    print('finally the average fitness of both sides is :', (favgLeft + favgRight) / 2)
    finalpoint = sum(result) / len(result) #average
    print('finally the result is :', finalpoint)
    d = deviance()
    print('deviance : ' , d,'\n')
    genResTups[0].append(d) #add to the deviance list
    genResTups.append((1/generationNumber,finalpoint))
    generationNumber += 50

plt.figure(); plt.xlabel('1/generationNumber') ; plt.ylabel('average result') 
i = 1
length = len(genResTups)
while(i < length) :
    plt.plot(genResTups[i][0],genResTups[i][1],'o') #the first element is the list of deviances
    i += 1
    
fitLine()

gSize = 4 #group size of results
cc = []
iters = 2 * ((length-1)/gSize) #number of times a group of results are chosen to find c then avg
i = 0
while(i < iters):
    cc.append(fLine(genResTups,gSize))
    i += 1

finResult(cc, iters)
